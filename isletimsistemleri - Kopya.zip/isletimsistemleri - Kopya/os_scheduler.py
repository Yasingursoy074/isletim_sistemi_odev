import csv
import copy
from collections import deque
import heapq
import threading
import os
import sys
import traceback

# --- Sabitler ve Ayarlar ---
CONTEXT_SWITCH_TIME = 0.001
ROUND_ROBIN_QUANTUM = 5 # Round Robin için Zaman Dilimi
PRIORITY_MAP = {'high': 1, 'normal': 2, 'low': 3} # Düşük sayı = Yüksek Öncelik
THROUGHPUT_TIMES = [50, 100, 150, 200]
INPUT_FILE_NAME = "case1.csv" # Case 1 için YENİ VE GÜNCEL AD

# --- 1. Veri Yapıları ve Temel Sınıflar ---
class Surec:
    """Bir süreci (Process) temsil eden sınıf."""
    def __init__(self, pid, arrival_time, burst_time, priority):
        self.pid = pid
        self.arrival_time = arrival_time
        self.burst_time = burst_time
        self.priority = priority
        
        self.remaining_time = float(burst_time)
        
        self.completion_time = 0.0
        self.start_time = -1.0
        self.waiting_time = 0.0
        self.turnaround_time = 0.0

    def __lt__(self, other):
        """heapq (öncelik kuyruğu) için karşılaştırma kuralı (SJF)."""
        return (self.remaining_time, self.arrival_time, self.pid) < \
               (other.remaining_time, other.arrival_time, other.pid)

    def __repr__(self):
        return f"Process(ID={self.pid}, AT={self.arrival_time}, BT={self.burst_time}, Rem={self.remaining_time}, P={self.priority})"


class SonucMetrikleri:
    """Bir algoritma çalıştırmasının sonuçlarını ve metriklerini tutar."""
    def __init__(self, algoritma_adi):
        self.algoritma_adi = algoritma_adi
        self.zaman_tablosu = [] 
        self.toplam_baglam_degistirme = 0
        self.surecler = [] 
        self.toplam_islemci_suresi = 0.0
        self.toplam_calisma_suresi = 0.0

    def surecleri_kaydet(self, tamamlanan_surecler):
        """Sonuçları hesaplamak için tamamlanan süreç listesini alır."""
        self.surecler = tamamlanan_surecler
        if self.zaman_tablosu:
            self.toplam_calisma_suresi = self.zaman_tablosu[-1][1]
            self.toplam_islemci_suresi = sum(p.burst_time for p in self.surecler)

    def metrikleri_hesapla(self):
        """Tüm ödev gereksinimlerini hesaplar."""
        if not self.surecler: return {}
        
        surec_sayisi = len(self.surecler)
        toplam_wt = sum(p.waiting_time for p in self.surecler)
        toplam_tat = sum(p.turnaround_time for p in self.surecler)
        
        metrikler = {}
        
        metrikler['Ortalama_WT'] = toplam_wt / surec_sayisi
        metrikler['Maksimum_WT'] = max(p.waiting_time for p in self.surecler)
        metrikler['Ortalama_TAT'] = toplam_tat / surec_sayisi
        metrikler['Maksimum_TAT'] = max(p.turnaround_time for p in self.surecler)

        metrikler['Throughput'] = {}
        for T in THROUGHPUT_TIMES:
            biten_surec_sayisi = sum(1 for p in self.surecler if p.completion_time <= T)
            metrikler['Throughput'][T] = biten_surec_sayisi / T if T > 0 else 0.0

        if self.toplam_calisma_suresi > 0:
            metrikler['CPU_Verimliligi'] = self.toplam_islemci_suresi / self.toplam_calisma_suresi
        else:
            metrikler['CPU_Verimliligi'] = 0.0
            
        metrikler['Baglam_Degistirme_Sayisi'] = self.toplam_baglam_degistirme
        
        return metrikler

    def zaman_tablosu_yazdir(self):
        """Örnek formatta zaman tablosunu döndürür."""
        cizelge_str = ""
        for start, end, pid in self.zaman_tablosu:
            start_r = round(start, 3)
            end_r = round(end, 3)
            cizelge_str += f"[{str(start_r).ljust(4)}] - - {pid} - - [{str(end_r).ljust(4)}]\n"
        return cizelge_str.strip()


# --- 2. CSV Okuma Fonksiyonu ---
def veri_oku(dosya_yolu):
    """CSV dosyasını okur ve Surec nesneleri listesi döndürür."""
    surecler = []
    try:
        with open(dosya_yolu, mode='r', encoding='utf-8') as file:
            reader = csv.reader(file)
            next(reader) # Başlık satırını atla
            for row in reader:
                if not row or len(row) < 4: continue
                try:
                    pid = row[0].strip()
                    arrival = int(row[1])
                    burst = int(row[2])
                    priority_str = row[3].strip().lower()
                    priority = PRIORITY_MAP.get(priority_str, 4) 
                    surecler.append(Surec(pid, arrival, burst, priority))
                except (ValueError) as e:
                    continue
    except FileNotFoundError:
        return None
        
    return sorted(surecler, key=lambda p: p.arrival_time)


# --- 3. Zamanlama Algoritmaları (6 Fonksiyon) ---

def hesapla_ve_kaydet_metrikler(surec_listesi, current_time):
    """Süreçler bittiğinde son metrikleri hesaplar."""
    for p in surec_listesi:
        p.completion_time = max(p.completion_time, current_time) 
        p.turnaround_time = p.completion_time - p.arrival_time
        p.waiting_time = p.turnaround_time - p.burst_time

# a) FCFS (Non-Preemptive)
def fcfs_calistir(gelen_surecler):
    algoritma_adi = "FCFS"
    processes = copy.deepcopy(gelen_surecler)
    sonuclar = SonucMetrikleri(algoritma_adi)
    current_time = 0.0
    tamamlanan_surecler = []
    
    for process in processes:
        
        if current_time < process.arrival_time:
            sonuclar.zaman_tablosu.append((current_time, float(process.arrival_time), "IDLE"))
            current_time = float(process.arrival_time)

        start_time = current_time
        
        if len(sonuclar.zaman_tablosu) > 0 and sonuclar.zaman_tablosu[-1][2] != "IDLE":
             sonuclar.toplam_baglam_degistirme += 1
             current_time += CONTEXT_SWITCH_TIME
             start_time += CONTEXT_SWITCH_TIME

        end_time = start_time + process.burst_time
        
        process.completion_time = end_time
        sonuclar.zaman_tablosu.append((start_time, end_time, process.pid))
        current_time = end_time
        tamamlanan_surecler.append(process)
        
    hesapla_ve_kaydet_metrikler(tamamlanan_surecler, current_time)
    sonuclar.surecleri_kaydet(tamamlanan_surecler)
    return sonuclar

# Non-Preemptive temel yapı
def non_preemptive_base(gelen_surecler, algoritma_adi, siralama_anahtarlari):
    processes = copy.deepcopy(gelen_surecler)
    sonuclar = SonucMetrikleri(algoritma_adi)
    current_time = 0.0
    process_index = 0
    tamamlanan_surecler = []
    ready_queue = [] # Min-Heap

    while len(tamamlanan_surecler) < len(processes):
        
        while process_index < len(processes) and processes[process_index].arrival_time <= current_time:
            p = processes[process_index]
            heapq.heappush(ready_queue, (p.__dict__[siralama_anahtarlari[0]], p.__dict__[siralama_anahtarlari[1]], p.pid, p))
            process_index += 1
        
        if not ready_queue:
            if process_index < len(processes):
                next_arrival = processes[process_index].arrival_time
                sonuclar.zaman_tablosu.append((current_time, float(next_arrival), "IDLE"))
                current_time = float(next_arrival)
                continue
            else:
                break

        (_, _, _, current_process) = heapq.heappop(ready_queue)
        
        start_time = current_time
        
        sonuclar.toplam_baglam_degistirme += 1
        current_time += CONTEXT_SWITCH_TIME
        start_time += CONTEXT_SWITCH_TIME
        
        end_time = start_time + current_process.burst_time
        current_time = end_time

        current_process.completion_time = end_time
        current_process.remaining_time = 0
        sonuclar.zaman_tablosu.append((start_time, end_time, current_process.pid))
        tamamlanan_surecler.append(current_process)
        
    hesapla_ve_kaydet_metrikler(tamamlanan_surecler, current_time)
    sonuclar.surecleri_kaydet(tamamlanan_surecler)
    return sonuclar

# b) Non-Preemptive SJF
def non_preemptive_sjf_calistir(gelen_surecler):
    return non_preemptive_base(gelen_surecler, "Non_Preemptive_SJF", ['burst_time', 'arrival_time'])

# e) Non-Preemptive Priority
def non_preemptive_priority_calistir(gelen_surecler):
    return non_preemptive_base(gelen_surecler, "Non_Preemptive_Priority", ['priority', 'arrival_time'])


# Preemptive temel yapı
def preemptive_base(gelen_surecler, algoritma_adi, siralama_anahtari):
    processes = copy.deepcopy(gelen_surecler)
    sonuclar = SonucMetrikleri(algoritma_adi)
    current_time = 0.0
    process_index = 0
    tamamlanan_surecler = []
    
    ready_queue = [] # Min-Heap
    current_process = None 
    last_block_start_time = 0.0

    while len(tamamlanan_surecler) < len(processes) or ready_queue:
        
        while process_index < len(processes) and processes[process_index].arrival_time <= current_time:
            p = processes[process_index]
            heapq.heappush(ready_queue, (p.__dict__[siralama_anahtari], p.arrival_time, p.pid, p))
            process_index += 1

        if not ready_queue:
            if process_index < len(processes):
                next_arrival = processes[process_index].arrival_time
                if current_time < next_arrival:
                    sonuclar.zaman_tablosu.append((current_time, float(next_arrival), "IDLE"))
                    current_time = float(next_arrival)
                continue
            else:
                break

        (next_key, _, _, next_process) = ready_queue[0] 
        is_preempted = False
        
        if current_process is None or current_process.pid != next_process.pid:
            current_key = current_process.__dict__[siralama_anahtari] if current_process else float('inf')
            if next_key < current_key:
                 is_preempted = True
        
        if is_preempted:
            if current_process is not None and current_process.remaining_time > 0:
                sonuclar.zaman_tablosu.append((last_block_start_time, current_time, current_process.pid))
                
                heapq.heappush(ready_queue, (current_process.__dict__[siralama_anahtari], current_process.arrival_time, current_process.pid, current_process))
                
                current_time += CONTEXT_SWITCH_TIME
                sonuclar.toplam_baglam_degistirme += 1
            
            heapq.heappop(ready_queue) 
            current_process = next_process
            last_block_start_time = current_time 

        time_to_run = current_process.remaining_time
        
        next_arrival_time = float('inf')
        if process_index < len(processes):
            next_arrival_time = processes[process_index].arrival_time

        if next_arrival_time < current_time + current_process.remaining_time:
            time_to_run = next_arrival_time - current_time

        current_process.remaining_time -= time_to_run
        current_time += time_to_run

        if current_process.remaining_time <= sys.float_info.epsilon:
            current_process.completion_time = current_time
            tamamlanan_surecler.append(current_process)
            
            sonuclar.zaman_tablosu.append((last_block_start_time, current_time, current_process.pid))
            current_process = None
        
    hesapla_ve_kaydet_metrikler(tamamlanan_surecler, current_time)
    sonuclar.surecleri_kaydet(tamamlanan_surecler)
    return sonuclar

# c) Preemptive SJF (SRTF)
def preemptive_sjf_calistir(gelen_surecler):
    return preemptive_base(gelen_surecler, "Preemptive_SJF (SRTF)", 'remaining_time')

# f) Preemptive Priority
def preemptive_priority_calistir(gelen_surecler):
    return preemptive_base(gelen_surecler, "Preemptive_Priority", 'priority')

# d) Round Robin (RR)
def round_robin_calistir(gelen_surecler, quantum=ROUND_ROBIN_QUANTUM):
    algoritma_adi = "Round_Robin"
    processes = copy.deepcopy(gelen_surecler)
    processes.sort(key=lambda p: p.arrival_time)
    sonuclar = SonucMetrikleri(algoritma_adi)
    current_time = 0.0
    process_index = 0
    tamamlanan_surecler = []
    
    ready_queue = deque()
    
    while len(tamamlanan_surecler) < len(processes) or ready_queue:
        
        while process_index < len(processes) and processes[process_index].arrival_time <= current_time:
            ready_queue.append(processes[process_index])
            process_index += 1

        if not ready_queue:
            if process_index < len(processes):
                next_arrival = processes[process_index].arrival_time
                if current_time < next_arrival:
                    sonuclar.zaman_tablosu.append((current_time, float(next_arrival), "IDLE"))
                    current_time = float(next_arrival)
                continue
            else:
                break

        current_process = ready_queue.popleft()
        start_time = current_time

        sonuclar.toplam_baglam_degistirme += 1
        current_time += CONTEXT_SWITCH_TIME
        start_time += CONTEXT_SWITCH_TIME
        
        time_to_run = min(quantum, current_process.remaining_time)

        current_process.remaining_time -= time_to_run
        current_time += time_to_run
        end_time = current_time
        
        sonuclar.zaman_tablosu.append((start_time, end_time, current_process.pid))

        if current_process.remaining_time <= sys.float_info.epsilon:
            current_process.completion_time = end_time
            tamamlanan_surecler.append(current_process)
        else:
            temp_list = []
            while process_index < len(processes) and processes[process_index].arrival_time <= current_time:
                temp_list.append(processes[process_index])
                process_index += 1
            
            ready_queue.extend(temp_list)
            ready_queue.append(current_process)
            
    hesapla_ve_kaydet_metrikler(tamamlanan_surecler, current_time)
    sonuclar.surecleri_kaydet(tamamlanan_surecler)
    return sonuclar

# --- Raporlama ve Threading Fonksiyonları ---

def rapor_olustur(algoritma_adi, sonuclar, durum_adi):
    """Algoritma sonuçlarını bir dosyaya yazar."""
    dosya_adi = f"{durum_adi}_{algoritma_adi}_Sonuclari.txt"
    try:
        with open(dosya_adi, 'w', encoding='utf-8') as f:
            metrikler = sonuclar.metrikleri_hesapla()
            
            f.write(f"*** {algoritma_adi} Zamanlama Algoritması Sonuçları ({durum_adi}) ***\n")
            f.write("----------------------------------------------------------------------\n\n")

            # a) Zaman Tablosu
            f.write("a) Zaman Tablosu (Gantt Chart) [start] - Pxx - [end]:\n")
            f.write(sonuclar.zaman_tablosu_yazdir() + "\n\n")
            
            # b, c, f. Metrikler
            f.write("--- Özet Metrikler ---\n")
            f.write(f"b) Maksimum ve Ortalama Bekleme Süresi (Waiting Time):\n")
            f.write(f"   Ortalama WT: {metrikler.get('Ortalama_WT', 0):.4f}\n")
            f.write(f"   Maksimum WT: {metrikler.get('Maksimum_WT', 0):.4f}\n\n")
            
            f.write(f"c) Maksimum ve Ortalama Tamamlanma Süresi (Turnaround Time):\n")
            f.write(f"   Ortalama TAT: {metrikler.get('Ortalama_TAT', 0):.4f}\n")
            f.write(f"   Maksimum TAT: {metrikler.get('Maksimum_TAT', 0):.4f}\n\n")
            
            f.write(f"f) Toplam Bağlam Değiştirme Sayısı:\n")
            f.write(f"   Sayısı: {metrikler.get('Baglam_Degistirme_Sayisi', 0)}\n\n")

            # d) Throughput
            f.write("d) İş Tamamlama Sayısı (Throughput) (T=[50, 100, 150, 200]):\n")
            for T, tp in metrikler.get('Throughput', {}).items():
                f.write(f"   T={T} için Throughput: {tp:.6f}\n")
            f.write("\n")
                
            # e) CPU Verimliliği
            f.write("e) Ortalama CPU Verimliliği:\n")
            f.write(f"   Verimlilik: {metrikler.get('CPU_Verimliligi', 0) * 100:.2f}%\n")
    except Exception as e:
        print(f"RAPOR YAZMA HATASI: {algoritma_adi} ({durum_adi}) raporu oluşturulurken bir hata oluştu: {e}")


def thread_target_wrapper(algoritma_adi, algoritma_fonksiyonu, surecler_kopyasi, durum_adi):
    """Thread'in hedef fonksiyonu. Raporlama ve simülasyonu çalıştırır."""
    try:
        sonuclar = algoritma_fonksiyonu(surecler_kopyasi)
        rapor_olustur(algoritma_adi, sonuclar, durum_adi)
    except Exception as e:
        print(f"HATA: {algoritma_adi} ({durum_adi}) algoritması çalışırken beklenmedik bir hata oluştu: {e}")


def ana_calistirici(dosya_yolu, durum_adi):
    """Tüm algoritmaları eş zamanlı çalıştırır."""
    
    surecler_orijinal = veri_oku(dosya_yolu)
    if surecler_orijinal is None:
        print(f"HATA: {dosya_yolu} dosyası bulunamadı veya okunamadı. Bu durum atlanıyor.")
        return

    algoritmalar = [
        ("FCFS", fcfs_calistir),
        ("Preemptive_SJF", preemptive_sjf_calistir),
        ("Non_Preemptive_SJF", non_preemptive_sjf_calistir),
        ("Round_Robin", round_robin_calistir),
        ("Preemptive_Priority", preemptive_priority_calistir),
        ("Non_Preemptive_Priority", non_preemptive_priority_calistir)
    ]

    print (f"\n--- {durum_adi} Başlatılıyor ({len(surecler_orijinal)})")